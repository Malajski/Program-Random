﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progress
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


                progressBar1.Value = 0;
                progressBar2.Value = 0;
                progressBar3.Value = 0;
                progressBar4.Value = 0;
                progressBar5.Value = 0;
                progressBar6.Value = 0;
                progressBar7.Value = 0;
                progressBar8.Value = 0;
                progressBar10.Value = 0;
                progressBar9.Value = 0;
                progressBar11.Value = 0;
                Random los = new Random();
                if (comboBox1.SelectedItem.ToString() == "WSZYSTKIE")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    int p = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;
                    progressBar5.Value = v;
                    progressBar6.Value = z;
                    progressBar7.Value = b;
                    progressBar8.Value = o;
                    progressBar10.Value = y;
                    progressBar9.Value = f;
                    progressBar11.Value = p;

                }
                if (comboBox1.SelectedItem.ToString() == "10")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;
                    progressBar5.Value = v;
                    progressBar6.Value = z;
                    progressBar7.Value = b;
                    progressBar8.Value = o;
                    progressBar10.Value = y;
                    progressBar9.Value = f;
                }
                if (comboBox1.SelectedItem.ToString() == "9")
                {
                    int x = los.Next(100) + 1;

                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;
                    progressBar5.Value = v;
                    progressBar6.Value = z;
                    progressBar7.Value = b;
                    progressBar8.Value = o;

                    progressBar9.Value = f;
                }
                if (comboBox1.SelectedItem.ToString() == "8")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;
                    progressBar5.Value = v;
                    progressBar6.Value = z;
                    progressBar7.Value = b;
                    progressBar8.Value = o;


                }
                if (comboBox1.SelectedItem.ToString() == "7")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;
                    progressBar5.Value = v;
                    progressBar6.Value = z;
                    progressBar7.Value = b;

                }
                if (comboBox1.SelectedItem.ToString() == "6")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;
                    progressBar5.Value = v;
                    progressBar6.Value = z;

                }
                if (comboBox1.SelectedItem.ToString() == "5")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;
                    progressBar5.Value = v;

                }
                if (comboBox1.SelectedItem.ToString() == "4")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;
                    progressBar4.Value = c;

                }
                if (comboBox1.SelectedItem.ToString() == "3")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;
                    progressBar3.Value = f;


                }
                if (comboBox1.SelectedItem.ToString() == "2")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;
                    progressBar2.Value = g;


                }
                if (comboBox1.SelectedItem.ToString() == "1")
                {
                    int x = los.Next(100) + 1;
                    int y = los.Next(100) + 1;
                    int z = los.Next(100) + 1;
                    int a = los.Next(100) + 1;
                    int v = los.Next(100) + 1;
                    int c = los.Next(100) + 1;
                    int b = los.Next(100) + 1;
                    int f = los.Next(100) + 1;
                    int g = los.Next(100) + 1;
                    int o = los.Next(100) + 1;
                    progressBar1.Value = x;


                }
            }
            catch (Exception ex)
            {
                progressBar1.Value = 0;
                progressBar2.Value = 0;
                progressBar3.Value = 0;
                progressBar4.Value = 0;
                progressBar5.Value = 0;
                progressBar6.Value = 0;
                progressBar7.Value = 0;
                progressBar8.Value = 0;
                progressBar10.Value = 0;
                progressBar9.Value = 0;
                progressBar11.Value = 0;
                MessageBox.Show("Wybierz opcje imprezy!", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void aUTORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Łukasz Niedźwiadek IIIB @2018");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("WSZYSTKIE");
            comboBox1.Items.Add("1");
            comboBox1.Items.Add("3");
            comboBox1.Items.Add("4");
            comboBox1.Items.Add("5");
            comboBox1.Items.Add("6");
            comboBox1.Items.Add("7");
            comboBox1.Items.Add("8");
            comboBox1.Items.Add("9");
            comboBox1.Items.Add("10");
        }

        private void pLIKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void wYJŚCIEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
